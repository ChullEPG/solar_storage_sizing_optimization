Only saturday was evaluated, because the other days could be finished with original 70kwh batteries.
The schedules of the different stage 4 loadsheddings with different battery sizes are given, along with the lateness.
Battery size was incremented 10kwh at a time until zero lateness.
The worst case (ls_pattern 3) battery size requirement was more finely determined.